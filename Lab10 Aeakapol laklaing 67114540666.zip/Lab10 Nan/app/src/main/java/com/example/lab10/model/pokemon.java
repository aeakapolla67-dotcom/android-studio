package com.example.lab10.model;

public class pokemon {
    private int Id;
    private String Name;
    private String Image;
    private int Vitality;
    private String Type;


    public pokemon(int Id, String Name, String Image, int Vitality, String Type) {
        this.Id = Id;
        this.Name = Name;
        this.Image = Image;
        this.Vitality = Vitality;
        this.Type = Type;
    }

    public int getId() { return Id; }
    public String getName() { return Name; }
    public String getImage() { return Image; }
    public int getVitality() { return Vitality; }
    public String getType() { return Type; }
}