package com.example.lab10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;
import com.example.lab10.model.pokemon;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    private List<pokemon> values;
    private Context context;

    public MyAdapter(List<pokemon> values, Context context) {
        this.values = values;
        this.context = context;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imgView;
        public TextView txtHeader;
        public TextView txtFooter;
        public View layout;

        public ViewHolder(View v) {
            super(v);
            layout = v;
            imgView = v.findViewById(R.id.imgView); // ตรวจสอบว่า R.id.imgView ถูกต้อง
            txtHeader = v.findViewById(R.id.txtHeader);
            txtFooter = v.findViewById(R.id.txtFooter);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.row_layout, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final pokemon food = values.get(position);
        holder.txtHeader.setText(food.getName());
        holder.txtFooter.setText("ค่าพลัง " +food.getVitality()+ " ธาตุ " + food.getType());
        android.util.Log.d("MyAdapter", "Loading image: " + food.getImage());

        Glide.with(context)
                .load(food.getImage())
                .placeholder(R.drawable.ic_launcher_background) // แสดงตอนกำลังโหลด
                .error(R.drawable.ic_launcher_foreground)       // แสดงถ้าโหลดไม่ได้
                .into(holder.imgView);

        holder.imgView.setOnClickListener(v -> {
            Toast.makeText(context, food.getName(), Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return values.size();
    }
}