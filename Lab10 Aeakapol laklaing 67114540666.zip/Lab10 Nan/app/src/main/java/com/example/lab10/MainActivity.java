package com.example.lab10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.lab10.model.pokemon;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    MyAdapter myAdapter;
    List<pokemon> pokemonList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // เพิ่ม pokemon พร้อมธาตุหลากหลาย
        pokemonList.add(new pokemon(
                1,
                "Pikachu",
                "https://images.pexels.com/photos/1716861/pexels-photo-1716861.jpeg?cs=srgb&dl=pexels-carocastilla-1716861.jpg&fm=jpg",
                320,
                "Electric"
        ));

        pokemonList.add(new pokemon(
                2,
                "Squirtle",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLXq-Knr5ZwhIv9maMYpnJPw-1yiaIGtxZRg&s",
                310,
                "Water"
        ));

        pokemonList.add(new pokemon(
                3,
                "Charrizard",
                "https://i.redd.it/w5oxyzk8nlj71.jpg",
                999,
                "Fire"
        ));

        pokemonList.add(new pokemon(
                4,
                "Deoxys",
                "https://i.pinimg.com/736x/ec/0e/e1/ec0ee111a8df245e95eadef1d02f220a.jpg",
                850,
                "Dark"
        ));

        pokemonList.add(new pokemon(
                5,
                "Espeon",
                "https://i.pinimg.com/474x/41/a5/62/41a56299d0fae723742293f56eb647be.jpg",
                770,
                "Psychic"
        ));

        pokemonList.add(new pokemon(
                6,
                "Torterra",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfwgRcb1A4I8to-j3eqizZHhTDfQu0WQuR5Q&s",
                810,
                "Nature"
        ));

        pokemonList.add(new pokemon(
                7,
                "Metagross",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGxpKoX5ycjh6xlL8KeVWTbWN3-0zTsub88g&s",
                900,
                "Metal"
        ));

        pokemonList.add(new pokemon(
                8,
                "Garchomp",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRCtagn0GvvTC963GerM6pSss5Evl7REI4B6g&s",
                920,
                "Earth"
        ));

        pokemonList.add(new pokemon(
                9,
                "Rayquaza",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQv0hFBKEu3sNNvTL9NZlzPeO7NGQYXkl7E9w&s",
                980,
                "Wind"
        ));

        pokemonList.add(new pokemon(
                10,
                "Glaceon",
                "https://i.redd.it/what-is-the-one-thing-you-love-about-glaceon-v0-3slplg2x221f1.jpg?width=1280&format=pjpg&auto=webp&s=9137610222cfa3975d90458124c0aeedd7fdfdb6",
                760,
                "Ice"
        ));

        recyclerView = findViewById(R.id.recyclerView);
        if (recyclerView == null) {
            throw new IllegalStateException("RecyclerView not found");
        }

        myAdapter = new MyAdapter(pokemonList, this);
        recyclerView.setAdapter(myAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
